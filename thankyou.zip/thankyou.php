 <head>
    <link rel="stylesheet" href="./css/bootstrap-5.1.3min.css">
    <link rel="stylesheet" href="./css/app.css">
 </head>
 
 <div class="success-bg">
    <h1  class="text-center"> message sent successfully</h1> <br>
        <a href="./index.html"  class="text-link fw-bold">Go to Home</a>
 </div>